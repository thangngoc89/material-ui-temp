'use strict';

Object.defineProperty(exports, "__esModule", {
  value: true
});
// Wait https://github.com/facebook/flow/issues/380 to be fixed
/* eslint-disable flowtype/require-valid-file-annotation */

var blueGrey = {
  50: '#eceff1',
  100: '#cfd8dc',
  200: '#b0bec5',
  300: '#90a4ae',
  400: '#78909c',
  500: '#607d8b',
  600: '#546e7a',
  700: '#455a64',
  800: '#37474f',
  900: '#263238',
  A100: '#cfd8dc',
  A200: '#b0bec5',
  A400: '#78909c',
  A700: '#455a64',
  contrastDefaultColor: 'light'
};

exports.default = blueGrey;