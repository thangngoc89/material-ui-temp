'use strict';

Object.defineProperty(exports, "__esModule", {
  value: true
});

var _Typography = require('./Typography');

Object.defineProperty(exports, 'default', {
  enumerable: true,
  get: function get() {
    return _interopRequireDefault(_Typography).default;
  }
});

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }