'use strict';

Object.defineProperty(exports, "__esModule", {
  value: true
});

var _Divider = require('./Divider');

Object.defineProperty(exports, 'default', {
  enumerable: true,
  get: function get() {
    return _interopRequireDefault(_Divider).default;
  }
});

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }